<template>
  <div >
    <EventChart/>
    <UsersChart/>
  </div>
</template>
<script setup>
  import EventChart from './workerStatEventChart.vue'
  import UsersChart from './workerStatUserChart.vue'

</script>
<style lang=""></style>