<template>
  <h3 
    class="text-base font-semibold leading-6 text-gray-900 w-full cursor-pointer"
    @click="$router.push({ name: 'activationkeys'})"
  >
    Активационные ключи
  </h3>
  <dd
    class="font-semibold mt-2 tracking-tight items-center h-[60%] text-white grid grid-cols-3 gap-4 md-max:justify-between xs-max:mt-4 xs-max:flex-col xs-max:w-full xs:grid-cols-1"
  >
    <blackStat
      title="Все"
      :icon="FolderIcon"
      :value="count?.activationKeys?.count"
      bg="bg-[#E9E7ED]"
      textColor="text-[#360B64]"
    />
    <blackStat
      title="Активированные"
      :icon="FolderPlusIcon"
      :value="count?.activationKeys?.activated"
      bg="bg-[#DCF7DD]"
      textColor="text-[#119A21]"
    />
    <blackStat
      title="Не активированные"
      :icon="FolderMinusIcon"
      bg="bg-[#FFECD9]"
      textColor="text-[#FF7E00]"
      :value="count?.activationKeys?.notActivated"
    />
  </dd>
</template>
<script setup>
  defineProps(['count'])

// Componenta import
  import blackStat from './blackStat.vue'

// Icon import
  import { FolderIcon, FolderPlusIcon, FolderMinusIcon } from '@heroicons/vue/24/outline'
</script>

