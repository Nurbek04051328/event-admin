<template>
  <div
    :class="` box flex  text-[${textColor || '#360B64'}] rounded-[26px] p-4 cursor-pointer shadow text-base justify-start space-y-2 items-start flex-col xs-max:w-full ${bg || 'bg-[#E9E7ED]'}  ${hoverBg ||'hover:bg-[#9E55EC]'} ${hoverText ||'hover:text-white'}`"
  >
    <div 
      class="text-sm font-bold lg:text-[13px] lg:break-words lg:max-w-24 md-max:max-w-full"
      :class="`${textColor? textColor : 'text-[#360B64]'}`"
    >
      {{ title }}
    </div>
    <div class="flex">
      <component :is="icon" class="h-6 w-6 shrink-0 mr-4" aria-hidden="true" :class="`${textColor? textColor : 'text-[#360B64]'} ${hoverText ||'hover:text-white'}`" />
      <div class="text-xl font-bold" :class="`${hoverText ||'hover:text-white'} ${textColor? textColor : 'text-[#360B64]'}`">{{ value || 0}}</div>
    </div>
  </div>
</template>
<script setup>
  // defineProps(['title', 'value', 'icon', 'bg', 'textColor', 'hoverBg', 'hoverText'])
  defineProps({
    title: {
      type: String
    },
    value: {
      type: String
    },
    icon: {
      type: String
    },
    bg: {
      type: String
    },
    textColor: {
      type: String
    },
    hoverBg: {
      type: String
    },
    hoverText: {
      type: String
    },
  })
</script>

<style lang="scss" scoped>
  .box {
    &:hover {
      div {
        color: white;
      }
      svg {
        stroke: white
      }
    }
  }
</style>
