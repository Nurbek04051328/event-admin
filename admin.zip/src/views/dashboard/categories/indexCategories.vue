<template>
  <head-part>
    <div class="mr-2 md-max:text-[14px]">
      <span class="text-lg text-gray-500 md-max:text-[14px]">Количество</span>: {{ category_store.categoryCount }}
    </div>
  </head-part>
  <div class="p-4 flex-1 flex flex-col items-start overflow-hidden">
    <CategoryTable
      :options="{
        languages
      }"
    />
  </div>
  <paginate
    v-if="category_store.categoryCount > limit"
    v-model="page"
    :page-count="Math.ceil(category_store.categoryCount / limit)"
    :page-range="3"
    :margin-pages="2"
    :click-handler="clickCallback"
    :prev-text="'Пред'"
    :next-text="'След'"
    :page-class="'page-item'"
    :container-class="'pagination_next shadow'"
  />
  <CategoryDialog
    :options="{
      languages
    }"
  />
</template>
<script setup>
import { storeToRefs } from 'pinia'
import { ref, onMounted } from 'vue'
import paginate from 'vuejs-paginate-next'
import CategoryTable from '@/components/data/dashboard/category/categoryTable.vue'
import CategoryDialog from '@/components/data/dashboard/category/categoryDialog.vue'

import { languageStore } from '@/stores/data/language'
const language_store = languageStore()
const { languages } = storeToRefs(language_store)

import { categoryStore } from '@/stores/data/categories'
const category_store = categoryStore()

const page = ref(1)
const limit = ref(30)

const clickCallback = async (value) => {
  page.value = value
  await getData()
}

const getData = async () => {
  await category_store.getCategories({ limit: limit.value, page: page.value })
}


onMounted(async () => {
  await language_store.getlanguages({ limit: 0 })
  getData()
})
</script>
<style lang=""></style>
