<template>
  <div class="auth h-dvh">
    <router-view />
  </div>
</template>

<style lang="scss">
.auth {
  background-color: #f3f4f6;
}
</style>
